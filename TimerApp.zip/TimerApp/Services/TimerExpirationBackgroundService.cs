using TimerAPP.Models;


public class TimerExpirationBackgroundService : BackgroundService
{
    private readonly TimerService _timerService;
    private readonly HttpClient _httpClient;
    private readonly ILogger<TimerExpirationBackgroundService> _logger;


    public TimerExpirationBackgroundService(TimerService timerService, ILogger<TimerExpirationBackgroundService> logger)
    {
        _timerService = timerService;
        _httpClient = new HttpClient();
        _logger = logger;
    }


    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
    
        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                var expiredTimers = await _timerService.GetExpiredTimersAsync();
                if(expiredTimers.Count > 0){
                    foreach (var timer in expiredTimers)
                    {    
                        var timerItem = await _timerService.GetTimerDetailsAsync(timer);
                        bool success = await TriggerWebhook(timerItem);

                       if(success){
                            await _timerService.DeleteTimerAsync(timerItem.id); 
                       }else{
                            await _timerService.UpdateTimerStatusAsync(timerItem.id,  "Failed");
                       }                    
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error processing timers.");
            }

            await Task.Delay(5000, stoppingToken); // Poll every 5 seconds
        }

    }
    
    private async Task<bool> TriggerWebhook(TimerItem timer)
    {
        try
        {
            var response = await _httpClient.PostAsync(timer.webhookUrl, null);
            return response.IsSuccessStatusCode;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to send webhook for timer {TimerId}", timer.id);
            return false;
         }
    }


    }


    
