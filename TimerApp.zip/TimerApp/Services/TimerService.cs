using System.Runtime.CompilerServices;
using StackExchange.Redis;
using TimerAPP.Models;


public class TimerService
{
    private readonly IDatabase _redisDb;


    public TimerService(RedisConnectionFactory redisFactory)
    {
        _redisDb = redisFactory.GetDatabase();
    }


    public async Task<string> SetTimerAsync(int ttlSeconds, string webhookUrl)
    {  
            var timerId = Guid.NewGuid().ToString();
            var expirationTimestamp = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds() + (ttlSeconds * 1000);

            await _redisDb.HashSetAsync(timerId, new HashEntry[]
            {
                new HashEntry("webhookUrl", webhookUrl),
                new HashEntry("status", "Started"),
                new HashEntry("createdAt", DateTime.UtcNow.ToString("o")), // ISO 8601 format
                new HashEntry("ttl", ttlSeconds)
            });

            // Add timer to the sorted set with expiration timestamp as score
            await _redisDb.SortedSetAddAsync("timers:index", timerId, expirationTimestamp);

            return timerId;
        
    }


    public async Task<string> GetTimerStatusAsync(string timerId)
    {
        var ttl = await _redisDb.KeyTimeToLiveAsync(timerId);
        return ttl?.TotalSeconds > 0 ? ttl.Value.TotalSeconds.ToString() : "0";
    }

    public async Task<TimerItem> GetTimerDetailsAsync(string timerId)
    {
        var result = await _redisDb.HashGetAllAsync(timerId);
        if (result.Length == 0)
        {
            throw new Exception("Timer details not found");
        }

        var timerItem = new TimerItem
        {
            id = timerId, 
            ttl = int.TryParse(result.FirstOrDefault(e => e.Name == "ttl").Value, out var ttl) ? ttl : 0,
            webhookUrl = result.FirstOrDefault(e => e.Name == "webhookUrl").Value.ToString() ?? string.Empty,
            dateCreated = result.FirstOrDefault(e => e.Name == "createdAt").Value.ToString() ?? string.Empty,
            status = result.FirstOrDefault(e => e.Name == "status").Value.ToString() ?? string.Empty
        };

         return timerItem;
    }


   public async Task<List<string>> GetExpiredTimersAsync()
    {
        var currentTimestamp = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();

        var expiredKeys = await _redisDb.SortedSetRangeByScoreAsync("timers:index", 0, currentTimestamp);

        return expiredKeys.Select(key => key.ToString()).ToList();
    }

    public async Task UpdateTimerStatusAsync(string timerId, string status)
    {
            await _redisDb.HashSetAsync(timerId, new HashEntry[] { new HashEntry("status", status) });

            // Remove from the sorted set
            await _redisDb.SortedSetRemoveAsync("timers:index", timerId);
    }


    public async Task DeleteTimerAsync(string timerId)
    {
            await _redisDb.KeyDeleteAsync(timerId);
            // Remove the timer ID from the sorted set
            await _redisDb.SortedSetRemoveAsync("timers:index", timerId);
    }
}
