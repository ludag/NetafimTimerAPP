using StackExchange.Redis;

public class RedisConnectionFactory
{
     private readonly ConnectionMultiplexer _redis;


    public RedisConnectionFactory()
    {
        _redis = ConnectionMultiplexer.Connect(
            new ConfigurationOptions
            {
                EndPoints = { "redis-15303.c8.us-east-1-3.ec2.redns.redis-cloud.com:15303" },
                User="default",
                Password="hb3NJlOiY3YcnP9xGYCEHTVTwDqe04fW", 
                AbortOnConnectFail = false 
            }
        );
    }


    public IDatabase GetDatabase() => _redis.GetDatabase();


    public ISubscriber GetSubscriber() => _redis.GetSubscriber();
}