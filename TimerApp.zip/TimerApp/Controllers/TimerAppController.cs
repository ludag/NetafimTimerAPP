using Microsoft.AspNetCore.Mvc;
using NetafimTimerAPP.Models;


namespace NetafimTimerAPP.Controllers;


[ApiController]
[Route("timerApp")]
public class TimerAppController : ControllerBase
{


    private readonly ILogger<TimerAppController> logger;
    private readonly TimerService timerService;


    public TimerAppController(ILogger<TimerAppController> _logger , TimerService _timerService)
    {
        logger = _logger;
        timerService= _timerService;


    }


    [HttpPost("setTimer")]
    public async Task<IActionResult> SetTimer([FromBody] TimerRequest request)
    { 
        try{
            var ttl = request.hours * 3600 + request.minutes * 60 + request.seconds;
            var timerId = await timerService.SetTimerAsync(ttl, request.webhookUrl);
            return Ok(new { id = timerId }); 
        }
        catch (Exception ex)
        {
            return StatusCode(500, $"Internal Server Error: {ex.Message}");
        }
    }


    [HttpGet("getTimerStatus/{id}")]
    public async Task<IActionResult> GetTimerStatus(string id)
    {
        try{
            var status = await timerService.GetTimerStatusAsync(id);
            return Ok(new { timeLeft = status });
        }
        catch (Exception ex)
        {
            return StatusCode(500, $"Internal Server Error: {ex.Message}");
        }
    }
}