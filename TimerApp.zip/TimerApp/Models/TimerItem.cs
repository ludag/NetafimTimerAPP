namespace TimerAPP.Models;


public class TimerItem
{
  public required string id {get; set;}
  public int  ttl {get; set;}
  public required String webhookUrl {get; set;}

  public required String dateCreated {get; set; }
 
  public required String status {get; set;}

}
