
namespace NetafimTimerAPP.Models;

public class TimerRequest
{
  public int  hours {get; set;}
  public int  minutes {get; set;}
  public int  seconds {get; set;}
  public required string webhookUrl {get; set;}


}
